package com.adso.tienda.enums;

import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor 
public enum RoleEnum {
    ADMIN(1L),
    CLIENTE(2L),
    VENDEDOR(3L);

    private final Long id;

    public Long getId(){
        return  id;
    }

    public static RoleEnum fromId(Long id){
        if (id == null) {
            return null;
        }
        for (RoleEnum role : RoleEnum.values()){
            if (role.getId().equals(id)) {
                return role;
            }
        }
        throw new IllegalArgumentException("ID de rol inválido: " + id);
    }
}
