package com.adso.tienda.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.adso.tienda.entity.Ordes;

public interface OerdesRepository  extends JpaRepository<Ordes,Long>{

    List<Ordes> findByClientId(Long clientId);
    
}
