package com.adso.tienda.service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.adso.tienda.dto.HttpGlobalresponseDTO;
import com.adso.tienda.dto.orders.OrderRequesCreadDTO;
import com.adso.tienda.dto.orders.OrdesResponseDTO;
import com.adso.tienda.entity.Ordes;
import com.adso.tienda.entity.Products;
import com.adso.tienda.enums.OrdesStatusEnum;
import com.adso.tienda.repository.OerdesRepository;
import com.adso.tienda.repository.ProductsRepository;

import lombok.RequiredArgsConstructor;

@Service 
@RequiredArgsConstructor 
public class OrdersService {
    
    private final OerdesRepository oerdesRepository;

    private final ProductsRepository productsRepository;

    public HttpGlobalresponseDTO<OrdesResponseDTO> creadOrder(Long userId, OrderRequesCreadDTO request) {
        HttpGlobalresponseDTO<OrdesResponseDTO> response = new HttpGlobalresponseDTO<>();
        OrdesResponseDTO ordeResponse = new OrdesResponseDTO();

        Optional<Products> producFound = productsRepository.findById(request.getIdProduct());

        if (producFound.isEmpty()) {
            response.setMessage("No hay un producto con ese id");
            response.setSuccess(false);
            return response;
        }

        Products produc = producFound.get();
        if (produc.getStock()<=0) {
            response.setMessage("No hay suficiente stock");
            response.setSuccess(false);
            return response;
        }

        Ordes order = new Ordes();
        order.setClientId(userId);
        order.setIdProduct(request.getIdProduct());
        order.setQuantity(request.getQuantity());

        BigDecimal total = produc.getPrice().multiply(BigDecimal.valueOf(request.getQuantity()));
        order.setTotal(total);
        order.setStatus(OrdesStatusEnum.PENDIENTE);

        oerdesRepository.save(order);

        ordeResponse.setId(order.getId());
        ordeResponse.setIdClient(userId);
        ordeResponse.setIdProduct(request.getIdProduct());
        ordeResponse.setQuantity(request.getQuantity());
        ordeResponse.setTotal(total);
        ordeResponse.setStatus(OrdesStatusEnum.PENDIENTE);
        ordeResponse.setCreatedAt(order.getCreatedAt());

        response.setMessage("Se creo el pedido");
        response.setData(ordeResponse);
        response.setSuccess(true);

        return response;
    }

    public HttpGlobalresponseDTO<List<OrdesResponseDTO>> getOrdersMine(Long userId) {
        HttpGlobalresponseDTO<List<OrdesResponseDTO>> response = new HttpGlobalresponseDTO<>();
        List<OrdesResponseDTO> listResponse = new ArrayList<>();

        List<Ordes> ordesFound = oerdesRepository.findByClientId(userId);

        if (ordesFound.isEmpty()) {
            response.setMessage("No hay ningun pedido . - .");
            response.setSuccess(false);
            return response;
        }

        for (Ordes ordes : ordesFound) {
            OrdesResponseDTO ordesResponse = new OrdesResponseDTO();
            ordesResponse.setId(ordes.getId());
            ordesResponse.setIdClient(ordes.getClientId());
            ordesResponse.setIdProduct(ordes.getIdProduct());
            ordesResponse.setQuantity(ordes.getQuantity());
            ordesResponse.setTotal(ordes.getTotal());
            ordesResponse.setStatus(ordes.getStatus());
            ordesResponse.setCreatedAt(ordes.getCreatedAt());

            listResponse.add(ordesResponse);
        }

        response.setData(listResponse);
        response.setMessage("Se encontraron sus pedidos");
        response.setSuccess(true);

        return response;
    }




}
